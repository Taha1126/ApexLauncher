package ir.apexmine.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 7, 17)
    private val panel = Color.rgb(20, 16, 38)
    private val purple = Color.rgb(151, 70, 255)
    private val pale = Color.rgb(239, 231, 255)
    private val muted = Color.rgb(173, 158, 207)
    private lateinit var root: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun base(title: String, subtitle: String): LinearLayout {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(root)
        setContentView(scroll)
        text(title, 27, pale, true, 0, 2)
        text(subtitle, 13, muted, false, 0, 18)
        return root
    }

    private fun showHome() {
        base("♛  APEX MINE", "لانچر اختصاصی سرور • Minecraft Bedrock")
        val hero = card()
        hero.addView(TextView(this).apply {
            text = "⛏"
            textSize = 50f
            gravity = Gravity.CENTER
            setTextColor(purple)
        })
        hero.addView(TextView(this).apply {
            text = "جهان Apex Mine"
            textSize = 24f
            setTextColor(pale)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        hero.addView(TextView(this).apply {
            text = "به سرور خودت خوش آمدی"
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(16))
        })
        root.addView(hero)
        button("▶   اجرای Minecraft", purple) { launchMinecraft() }
        button("✦   سرورها", panel) { showServers() }
        button("⚙   وضعیت و راهنما", panel) { showHelp() }
        text("نسخه هدف: 1.21.51  •  Bedrock", 12, muted, false, 0, 0)
    }

    private fun showServers() {
        base("سرورها", "سرورهای ذخیره‌شده در لانچر")
        val c = card()
        text("♛  Apex Mine", 22, pale, true, 0, 8, c)
        text("آدرس: play.apexgaming.ir", 14, muted, false, 0, 5, c)
        text("پورت: 19132", 14, muted, false, 0, 5, c)
        text("نسخه پیشنهادی: 1.21.51", 14, muted, false, 0, 14, c)
        button("افزودن سرور و باز کردن Minecraft", purple) { addServerAndLaunch() }
        button("نسخه Minecraft نصب‌شده را اجرا کن", panel) { launchMinecraft() }
        button("بازگشت", panel) { showHome() }
        text("نکته: پشتیبانی از لینک افزودن سرور به نسخه Minecraft و دستگاه بستگی دارد.", 12, muted, false, 0, 0)
    }

    private fun showHelp() {
        base("راهنما", "چند نکته پیش از اتصال")
        val c = card()
        text("۱. Minecraft Bedrock باید روی گوشی نصب باشد.", 15, pale, false, 0, 10, c)
        text("۲. اگر لینک افزودن سرور پشتیبانی نشود، Minecraft را باز کن و اطلاعات سرور را دستی وارد کن.", 15, pale, false, 0, 10, c)
        text("۳. نسخه 1.21.51 فقط نسخه پیشنهادی است؛ امکان اتصال به نسخه فعلی سرور باید بررسی شود.", 15, pale, false, 0, 10, c)
        button("بررسی و اجرای Minecraft", purple) { launchMinecraft() }
        button("سرورها", panel) { showServers() }
        button("خانه", panel) { showHome() }
    }

    private fun launchMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent != null) {
            startActivity(intent)
        } else {
            statusMessage("Minecraft Bedrock روی گوشی پیدا نشد. ابتدا نسخه رسمی بازی را نصب کن.")
        }
    }

    private fun addServerAndLaunch() {
        val server = "Apex Mine"
        val address = "play.apexgaming.ir:19132"
        val uri = Uri.parse("minecraft://?addExternalServer=${Uri.encode(server)}|${Uri.encode(address)}")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
            if (intent != null) startActivity(intent)
            else statusMessage("Minecraft نصب نیست یا این نسخه از لینک افزودن سرور پشتیبانی نمی‌کند.")
        }
    }

    private fun statusMessage(message: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Apex Mine")
            .setMessage(message)
            .setPositiveButton("باشه", null)
            .show()
    }

    private fun card(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(panel)
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = dp(14)
        root.addView(box, p)
        return box
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean, top: Int, bottom: Int, parent: LinearLayout = root) {
        parent.addView(TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(top), 0, dp(bottom))
        })
    }

    private fun button(label: String, color: Int, action: () -> Unit) {
        val b = TextView(this).apply {
            text = label
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(16), dp(14), dp(16))
            setBackgroundColor(color)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = dp(12)
        root.addView(b, p)
    }

    private fun statusMessageUnused() {}
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
